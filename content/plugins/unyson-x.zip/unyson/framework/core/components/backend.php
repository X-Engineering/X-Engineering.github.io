<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

/**
 * Backend functionality
 */
final class _FW_Component_Backend {

	/** @var FW_Settings_Form */
	private $settings_form;

	private $available_render_designs = array(
		'default', 'taxonomy', 'customizer', 'empty'
	);

	private $default_render_design = 'default';

	/**
	 * The singleton instance of Parsedown class that is used across
	 * whole framework.
	 *
	 * @since 2.6.9
	 */
	private $markdown_parser = null;

	/**
	 * Contains all option types
	 * @var FW_Option_Type[]
	 */
	private $option_types = array();

	/**
	 * @var FW_Option_Type_Undefined
	 */
	private $undefined_option_type;

	/**
	 * Store container types for registration, until they will be required
	 * @var array|false
	 *      array Can have some pending container types in it
	 *      false Container types already requested and was registered, so do not use pending anymore
	 */
	private $container_types_pending_registration = array();

	/**
	 * Contains all container types
	 * @var FW_Container_Type[]
	 */
	private $container_types = array();

	/**
	 * @var FW_Container_Type_Undefined
	 */
	private $undefined_container_type;

	private $static_registered = false;

	/**
	 * @var FW_Access_Key
	 */
	private $access_key;

	/**
	 * @internal
	 */
	public function _get_settings_page_slug() {
		return apply_filters( 'fw_get_settings_page_slug', 'fw-settings' );
	}

	/**
	 * @return string
	 * @since 2.6.3
	 */
	public function get_options_name_attr_prefix() {
		return 'fw_options';
	}

	/**
	 * @return string
	 * @since 2.6.3
	 */
	public function get_options_id_attr_prefix() {
		return 'fw-option-';
	}

	private function get_current_edit_taxonomy() {
		static $cache_current_taxonomy_data = null;

		if ( $cache_current_taxonomy_data !== null ) {
			return $cache_current_taxonomy_data;
		}

		$result = array(
			'taxonomy' => null,
			'term_id'  => 0,
		);

		do {
			if ( ! is_admin() ) {
				break;
			}

			// code from /wp-admin/admin.php line 110
			{
				if ( isset( $_REQUEST['taxonomy'] ) && taxonomy_exists( $_REQUEST['taxonomy'] ) ) {
					$taxnow = $_REQUEST['taxonomy'];
				} else {
					$taxnow = '';
				}
			}

			if ( empty( $taxnow ) ) {
				break;
			}

			$result['taxonomy'] = $taxnow;

			if ( empty( $_REQUEST['tag_ID'] ) ) {
				return $result;
			}

			// code from /wp-admin/edit-tags.php
			{
				$tag_ID = (int) $_REQUEST['tag_ID'];
			}

			$result['term_id'] = $tag_ID;
		} while ( false );

		$cache_current_taxonomy_data = $result;

		return $cache_current_taxonomy_data;
	}

	public function __construct() {}

	/**
	 * @internal
	 */
	public function _init() {
		if ( is_admin() ) {
			$this->settings_form = new FW_Settings_Form_Theme('theme-settings');
		}

		$this->add_actions();
		$this->add_filters();
	}

	/**
	 * @internal
	 */
	public function _after_components_init() {}

	private function get_access_key()
	{
		if (!$this->access_key) {
			$this->access_key = new FW_Access_Key('fw_backend');
		}

		return $this->access_key;
	}

	private function add_actions() {
		if ( is_admin() ) {
			add_action('add_meta_boxes', array($this, '_action_create_post_meta_boxes'), 10, 2);
			add_action('init', array($this, '_action_init'), 20);
			add_action('admin_enqueue_scripts', array($this, '_action_admin_register_scripts'),
				/**
				 * Usually when someone register/enqueue a script/style to be used in other places
				 * in 'admin_enqueue_scripts' actions with default (not set) priority 10, they use priority 9.
				 * Use here priority 8, in case those scripts/styles used in actions with priority 9
				 * are using scripts/styles registered here
				 */
				8
			);
			add_action('admin_enqueue_scripts', array($this, '_action_admin_enqueue_scripts'),
				/**
				 * In case some custom defined option types are using script/styles registered
				 * in actions with default priority 10 (make sure the enqueue is executed after register)
				 */
				11
			);
			add_action( 'admin_menu', array( $this, '_action_admin_menu' ) );

			// render and submit options from javascript
			{
				add_action('wp_ajax_fw_backend_options_render', array($this, '_action_ajax_options_render'));
				add_action('wp_ajax_fw_backend_options_get_values', array($this, '_action_ajax_options_get_values'));
				add_action('wp_ajax_fw_backend_options_get_values_json', array($this, '_action_ajax_options_get_values_json'));
			}
		}

		add_action('save_post', array($this, '_action_save_post'), 7, 3);
		add_action('wp_restore_post_revision', array($this, '_action_restore_post_revision'), 10, 2);
		add_action( '_wp_put_post_revision', array( $this, '_action__wp_put_post_revision' ) );

		add_action('customize_register', array($this, '_action_customize_register'), 7);
	}

	public function _action_admin_menu() {

		$parent_slug = 'index.php';
		$menu_title  = esc_html__( 'New', 'fw' );

		if ( isset( $GLOBALS['admin_page_hooks'] ) ) {
			$parent_slug = 'fw-extensions';
			$menu_title  = esc_html__( 'New', 'fw' );
		}

		add_submenu_page(
			$parent_slug,
			esc_html__( 'New', 'fw' ),
			$menu_title,
			'manage_options',
			'fw-new',
			array( $this, 'render_about_page' )
		);
	}

	public function render_about_page() {

		$file = WP_PLUGIN_DIR . '/unyson/framework/views/about.php';

		if ( file_exists( $file ) ) {
			include $file;
		}
	}

	private function add_filters() {
		if ( is_admin() ) {
			add_filter('admin_footer_text', array($this, '_filter_admin_footer_text'), 11);
			add_filter('update_footer', array($this, '_filter_footer_version'), 11);
		}
	}

	/**
	 * @param string|FW_Option_Type $option_type_class
	 * @param string|null $type
	 *
	 * @internal
	 */
	private function register_option_type( $option_type_class, $type = null ) {
		if ( $type == null ) {
			try {
				$type = $this->get_instance( $option_type_class )->get_type();
			} catch ( FW_Option_Type_Exception_Invalid_Class $exception ) {
				if ( ! is_subclass_of( $option_type_class, 'FW_Option_Type' ) ) {
					trigger_error( 'Invalid option type class ' . get_class( $option_type_class ), E_USER_WARNING );

					return;
				}
			}
		}

		if ( isset( $this->option_types[ $type ] ) ) {
			trigger_error( 'Option type "' . $type . '" already registered', E_USER_WARNING );

			return;
		}

		$this->option_types[$type] = $option_type_class;
	}

	/**
	 * @param string|FW_Container_Type $container_type_class
	 * @param string|null $type
	 *
	 * @internal
	 */
	private function register_container_type( $container_type_class, $type = null ) {
		if ( $type == null ) {
			try {
				$type = $this->get_instance( $container_type_class )->get_type();
			} catch ( FW_Option_Type_Exception_Invalid_Class $exception ) {
				if ( ! is_subclass_of( $container_type_class, 'FW_Container_Type' ) ) {
					trigger_error( 'Invalid container type class ' . get_class( $container_type_class ), E_USER_WARNING );

					return;
				}
			}
		}

		if ( isset( $this->container_types[ $type ] ) ) {
			trigger_error( 'Container type "' . $type . '" already registered', E_USER_WARNING );

			return;
		}

		$this->container_types[$type] = $container_type_class;
	}

	private function register_static() {
		if (
			!doing_action('admin_enqueue_scripts')
			&&
			!did_action('admin_enqueue_scripts')
		) {
			/**
			 * Do not wp_enqueue/register_...() because at this point not all handles has been registered
			 * and maybe they are used in dependencies in handles that are going to be enqueued.
			 * So as a result some handles will not be equeued because of not registered dependecies.
			 */
			return;
		}

		if ( $this->static_registered ) {
			return;
		}

		/**
		 * Register styles/scripts only in admin area, on frontend it's not allowed to use styles/scripts from framework backend core
		 * because they are meant to be used only in backend and can be changed in the future.
		 * If you want to use a style/script from framework backend core, copy it to your theme and enqueue as a theme style/script.
		 */
		if ( ! is_admin() ) {
			$this->static_registered = true;

			return;
		}

		wp_register_script(
			'fw-events',
			fw_get_framework_directory_uri( '/static/js/fw-events.js' ),
			array(),
			fw()->manifest->get_version(),
			true
		);

		wp_register_script(
			'fw-ie-fixes',
			fw_get_framework_directory_uri( '/static/js/ie-fixes.js' ),
			array(),
			fw()->manifest->get_version(),
			true
		);

		{
			wp_register_style(
				'qtip',
				fw_get_framework_directory_uri( '/static/libs/qtip/css/jquery.qtip.min.css' ),
				array(),
				fw()->manifest->get_version()
			);
			wp_register_script(
				'qtip',
				fw_get_framework_directory_uri( '/static/libs/qtip/jquery.qtip.min.js' ),
				array( 'jquery' ),
				fw()->manifest->get_version()
			);
		}

		/**
		 * Important!
		 * Call wp_enqueue_media() before wp_enqueue_script('fw') (or using 'fw' in your script dependencies)
		 * otherwise fw.OptionsModal won't work
		 */
		{
			wp_register_style(
				'fw',
				fw_get_framework_directory_uri( '/static/css/fw.css' ),
				array( 'qtip' ),
				fw()->manifest->get_version()
			);

			wp_register_script(
				'fw-reactive-options-registry',
				fw_get_framework_directory_uri(
					'/static/js/fw-reactive-options-registry.js'
				),
				array('fw', 'fw-events'),
				false
			);

			wp_register_script(
				'fw-reactive-options-simple-options',
				fw_get_framework_directory_uri(
					'/static/js/fw-reactive-options-simple-options.js'
				),
				array('fw', 'fw-events', 'fw-reactive-options-undefined-option'),
				false
			);

			wp_register_script(
				'fw-reactive-options-undefined-option',
				fw_get_framework_directory_uri(
					'/static/js/fw-reactive-options-undefined-option.js'
				),
				array(
					'fw', 'fw-events', 'fw-reactive-options-registry'
				),
				false
			);

			wp_register_script(
				'fw-reactive-options',
				fw_get_framework_directory_uri('/static/js/fw-reactive-options.js'),
				array(
					'fw', 'fw-events', 'fw-reactive-options-undefined-option',
					'fw-reactive-options-simple-options'
				),
				false
			);

			wp_register_script(
				'fw',
				fw_get_framework_directory_uri( '/static/js/fw.js' ),
				array( 'jquery', 'fw-events', 'backbone', 'qtip' ),
				fw()->manifest->get_version(),
				false // false fixes https://github.com/ThemeFuse/Unyson/issues/1625#issuecomment-224219454
			);

			wp_localize_script( 'fw', '_fw_localized', array(
				'FW_URI'     => fw_get_framework_directory_uri(),
				'SITE_URI'   => site_url(),
				'LOADER_URI' => apply_filters( 'fw_loader_image', fw_get_framework_directory_uri() . '/static/img/logo.svg' ),
				'l10n'       => array_merge(
					$l10n = array(
						'modal_save_btn' => __( 'Save', 'fw' ),
						'done'     => __( 'Done', 'fw' ),
						'ah_sorry' => __( 'Ah, Sorry', 'fw' ),
						'reset'    => __( 'Reset', 'fw' ),
						'apply'    => __( 'Apply', 'fw' ),
						'cancel'   => __( 'Cancel', 'fw' ),
						'ok'       => __( 'Ok', 'fw' )
					),
					/**
					 * fixes https://github.com/ThemeFuse/Unyson/issues/2381
					 * @since 2.6.14
					 */
					apply_filters('fw_js_l10n', $l10n)
				),
				'options_modal' => array(
					/** @since 2.6.13 */
					'default_reset_bnt_disabled' => apply_filters('fw:option-modal:default:reset-btn-disabled', false)
				),
			) );
		}

		{
			wp_register_style(
				'fw-backend-options',
				fw_get_framework_directory_uri( '/static/css/backend-options.css' ),
				array( 'fw' ),
				fw()->manifest->get_version()
			);

			wp_register_script(
				'fw-backend-options',
				fw_get_framework_directory_uri( '/static/js/backend-options.js' ),
				array( 'fw', 'fw-events', 'fw-reactive-options', 'postbox', 'jquery-ui-tabs' ),
				fw()->manifest->get_version(),
				true
			);

			wp_localize_script( 'fw', '_fw_backend_options_localized', array(
				'lazy_tabs' => fw()->theme->get_config('lazy_tabs')
			) );
		}

		{
			wp_register_style(
				'fw-selectize',
				fw_get_framework_directory_uri( '/static/libs/selectize/selectize.css' ),
				array(),
				fw()->manifest->get_version()
			);
			wp_register_script(
				'fw-selectize',
				fw_get_framework_directory_uri( '/static/libs/selectize/selectize.min.js' ),
				array( 'jquery', 'fw-ie-fixes' ),
				fw()->manifest->get_version(),
				true
			);
		}

		{
			wp_register_script(
				'fw-mousewheel',
				fw_get_framework_directory_uri( '/static/libs/mousewheel/jquery.mousewheel.min.js' ),
				array( 'jquery' ),
				fw()->manifest->get_version(),
				true
			);
		}

		{
			wp_register_style(
				'fw-jscrollpane',
				fw_get_framework_directory_uri( '/static/libs/jscrollpane/jquery.jscrollpane.css' ),
				array(),
				fw()->manifest->get_version()
			);
			wp_register_script( 'fw-jscrollpane',
				fw_get_framework_directory_uri( '/static/libs/jscrollpane/jquery.jscrollpane.min.js' ),
				array( 'jquery', 'fw-mousewheel' ),
				fw()->manifest->get_version(),
				true
			);
		}

		wp_register_style(
			'font-awesome',
			fw_get_framework_directory_uri( '/static/libs/font-awesome/css/font-awesome.min.css' ),
			array(),
			fw()->manifest->get_version()
		);
		/**
		 * backwards compatibility, in case extensions are not up-to-date
		 * todo: remove in next major version
		 * https://github.com/ThemeFuse/Unyson/issues/2198
		 * @deprecated
		 */
		wp_register_style('fw-font-awesome', fw_get_framework_directory_uri( '/static/libs/font-awesome/css/font-awesome.min.css' ));

		wp_register_script(
			'backbone-relational',
			fw_get_framework_directory_uri( '/static/libs/backbone-relational/backbone-relational.js' ),
			array( 'backbone' ),
			fw()->manifest->get_version(),
			true
		);

		wp_register_script(
			'fw-uri',
			fw_get_framework_directory_uri( '/static/libs/uri/URI.js' ),
			array(),
			fw()->manifest->get_version(),
			true
		);

		wp_register_script(
			'fw-moment',
			/**
			 * IMPORTANT: At the end of the script is added this line:
			 * moment.locale(document.documentElement.lang.slice(0, 2)); // fixes https://github.com/ThemeFuse/Unyson/issues/1767
			 */
			fw_get_framework_directory_uri( '/static/libs/moment/moment-with-locales.min.js' ),
			array(),
			fw()->manifest->get_version(),
			true
		);

		wp_register_script(
			'fw-form-helpers',
			fw_get_framework_directory_uri( '/static/js/fw-form-helpers.js' ),
			array( 'jquery' ),
			fw()->manifest->get_version(),
			true
		);

		wp_register_style(
			'fw-unycon',
			fw_get_framework_directory_uri( '/static/libs/unycon/unycon.css' ),
			array(),
			fw()->manifest->get_version()
		);

		$this->static_registered = true;
	}

	/**
	 * @param $class
	 *
	 * @return FW_Option_Type
	 * @throws FW_Option_Type_Exception_Invalid_Class
	 */
	protected function get_instance( $class ) {
		if ( ! class_exists( $class )
		     || (
			     ! is_subclass_of( $class, 'FW_Option_Type' )
			     &&
			     ! is_subclass_of( $class, 'FW_Container_Type' )
		     )
		) {
			throw new FW_Option_Type_Exception_Invalid_Class( $class );
		}

		return new $class;
	}

	public function _filter_admin_footer_text( $html ) {
		if (
			(
				current_user_can( 'update_themes' )
				||
				current_user_can( 'update_plugins' )
			)
			&&
			fw_current_screen_match(array(
				'only' => array(
					array('parent_base' => fw()->extensions->manager->get_page_slug()) // Unyson Extensions page
				)
			))
		) {
			return ( empty( $html ) ? '' : $html . '<br/>' )
			. '<em>'
			. str_replace(
				array(
					'{wp_review_link}',
					'{facebook_share_link}',
					'{twitter_share_link}',
				),
				array(
					fw_html_tag('a', array(
						'target' => '_blank',
						'href'   => 'https://wordpress.org/support/view/plugin-reviews/unyson?filter=5#postform',
					), __('leave a review', 'fw')),
					fw_html_tag('a', array(
						'target' => '_blank',
						'href'   => 'https://www.facebook.com/sharer/sharer.php?'. http_build_query(array(
							'u' => 'http://unyson.io',
						)),
						'onclick' => 'return !window.open(this.href, \'Facebook\', \'width=640,height=300\')',
					), __('Facebook', 'fw')),
					fw_html_tag('a', array(
						'target' => '_blank',
						'href'   => 'https://twitter.com/home?'. http_build_query(array(
							'status' => __('Unyson WordPress Framework is the fastest and easiest way to develop a premium theme. I highly recommend it', 'fw')
								.' http://unyson.io/ #UnysonWP',
						)),
						'onclick' => 'return !window.open(this.href, \'Twitter\', \'width=640,height=430\')',
					), __('Twitter', 'fw')),
				),
				__('If you like Unyson, {wp_review_link}, share on {facebook_share_link} or {twitter_share_link}.', 'fw')
			)
			. '</em>';
		} else {
			return $html;
		}
	}

	/**
	 * Print framework version in the admin footer
	 *
	 * @param string $html
	 *
	 * @return string
	 * @internal
	 */
	public function _filter_footer_version( $html ) {
		if ( current_user_can( 'x_user' ) || current_user_can( 'update_themes' ) || current_user_can( 'update_plugins' ) || true ) {
			return ( empty( $html ) ? '' : $html . ' | ' ) . '<label id="xeng-p" style="white-space: nowrap;font-size: 11px;color: #9097aa;letter-spacing: -0.0025em;"> Powered by <a id="xeng-link" href="https://x-engineering.github.io" target="_blank" rel="noopener"><svg xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:cc="http://creativecommons.org/ns#" xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:svg="http://www.w3.org/2000/svg" xmlns="http://www.w3.org/2000/svg" style="width: 88px !important;margin-bottom: 5px;/*! padding-top: 5px; */padding-left: 3px;vertical-align: middle;" viewBox="0 0 6490.816 1984.375" version="1.1" id="xeng-inline-logo"> <title id="title">X Engineering</title> <defs id="defs1755"> <filter style="color-interpolation-filters:sRGB" id="filter1722" x="-0.19395426" y="-0.19678824" width="1.4373866" height="1.4437774"> <feFlood flood-opacity="0.254902" flood-color="rgb(0,0,0)" result="flood" id="feFlood1712"></feFlood> <feComposite in="flood" in2="SourceGraphic" operator="in" result="composite1" id="feComposite1714"></feComposite> <feGaussianBlur in="composite1" stdDeviation="9.8" result="blur" id="feGaussianBlur1716"></feGaussianBlur> <feOffset dx="6" dy="6" result="offset" id="feOffset1718"></feOffset> <feComposite in="SourceGraphic" in2="offset" operator="over" result="composite2" id="feComposite1720"></feComposite> </filter> <filter style="color-interpolation-filters:sRGB" id="filter1090" x="-0.024528366" y="-0.15201971" width="1.0553139" height="1.34282"> <feFlood flood-opacity="0.254902" flood-color="rgb(0,0,0)" result="flood" id="feFlood1080"></feFlood> <feComposite in="flood" in2="SourceGraphic" operator="in" result="composite1" id="feComposite1082"></feComposite> <feGaussianBlur in="composite1" stdDeviation="9.8" result="blur" id="feGaussianBlur1084"></feGaussianBlur> <feOffset dx="6" dy="6" result="offset" id="feOffset1086"></feOffset> <feComposite in="SourceGraphic" in2="offset" operator="over" result="composite2" id="feComposite1088"></feComposite> </filter> </defs> <g id="layer1" transform="translate(-199.54714,-297.65627)"> <g id="g2058" transform="matrix(3.96875,0,0,3.96875,155.656,240.10939)" style="image-rendering:auto"> <path class="st0" d="m 483.1,52.3 c 1.8,0 2.7,2.1 1.4,3.4 -21.5,21.9 -43,43.9 -64.5,65.8 -38.2,38.9 -76.5,77.7 -114.7,116.7 -0.7,0.8 -1.9,1.3 -2.4,2.3 -0.4,0.8 -1.3,1.2 -2.2,1 -1.1,-0.2 -2.2,-0.2 -3.3,-0.2 -31.5,0 -62.9,0 -94.4,0 -1.4,0 -3.1,-0.7 -4.2,1.1 -2.4,-2.2 0.5,-3 1.3,-3.9 14.1,-14.5 28.3,-28.9 42.5,-43.3 45.9,-46.7 91.8,-93.3 137.8,-140 0.9,-0.9 1.9,-1.7 2.9,-2.6 0.4,-0.3 0.8,-0.5 1.3,-0.5 32.8,0.1 65.6,0.1 98.5,0.2 z" id="path2022"></path> <path class="st1" d="m 198.8,242.3 c 1,-1.8 2.8,-1.1 4.2,-1.1 31.5,0 62.9,0 94.4,0 1.9,0 3.7,0 5.4,1 11,11 22,21.9 32.9,33 49,49.7 98,99.5 146.9,149.3 1.4,1.4 3.4,2.4 3.3,4.8 -1.5,1.1 -3.2,1 -4.9,1 -32.4,0 -64.8,0 -97.2,0 -14.1,-14.2 -28.3,-28.4 -42.3,-42.6 -46.7,-47.4 -93.3,-94.8 -140,-142.2 -1,-1 -1.8,-2.1 -2.7,-3.2 z" id="path2024"></path> <path class="st2" d="m 11.5,429.7 c 5.4,-5.3 9,-8.9 13.9,-13.8 49.3,-50.1 98.6,-100.1 147.8,-150.3 2.7,-2.7 4,-2.8 6.7,0 15.2,15.8 30.6,31.4 46.1,46.9 2.5,2.5 2.4,3.7 0,6.2 -36.2,36.6 -72.3,73.3 -108.3,110 -1.5,1.6 -2.9,2.8 -5.4,2.8 -33.3,-0.1 -66.6,-0.1 -100,-0.1 -1.6,0.2 -1.4,-0.9 -0.8,-1.7 z" id="path2026"></path> <path class="st3" d="M 13.6,53.7 C 13,53 13.5,51.9 14.4,51.9 c 33.5,0 65.9,0 98.3,0 1.7,0 2.8,0.6 4,1.8 36.3,36.9 72.6,73.8 109,110.7 2.1,2.1 2.2,3.1 -0.1,5.4 -12.1,12 -24,24.4 -36,36.6 -3.3,3.4 -6.4,6.8 -9.7,10.2 -2,2.1 -3.5,2.8 -6.2,0.1 -53,-54.1 -106.2,-108 -159.3,-162 -0.2,-0.4 -0.5,-0.7 -0.8,-1 z" id="path2028"></path> <path class="st4" d="M 484,514.5" id="path2032"></path> <path class="st0" d="M 260.4,499.6" id="path2034"></path> <path class="st0" d="m 442.2,503.9 m 7.4,-12.7 m -15.3,-10.3 m -11.5,9.6 m -0.7,5" id="path2036"></path> <path class="st0" d="M 288.7,504.3" id="path2038"></path> <path class="st0" d="M 294.3,493.2" id="path2040"></path> <path class="st0" d="M 483.9,471.8" id="path2042"></path> <path class="st4" d="m 340.4,503.6 c 0.2,-0.1 0.4,-0.3 0.5,-0.4" id="path2044"></path> <path class="st4" d="M 521,503.6" id="path2046"></path> <path class="st4" d="M 528.2,483" id="path2048"></path> <path class="st5" d="m 271.1,507.6 c 1.8,0 3.6,0 5.5,0" id="path2050"></path> <path class="st4" d="M 446.5,491.4" id="path2052"></path> <path class="st5" d="M 540.5,18.2" id="path2054"></path> <path class="st5" d="M 535.7,14.5" id="path2056"></path> </g> <path style="fill:#616569;stroke:none;stroke-width:0.264583;filter:url(#filter1090)" d="m 1254.3379,2188.3647 c 1.5597,-11.5834 5.7962,-23.315 8.6325,-34.6604 l 2.0495,-8.2021 c 0.223,-0.8916 0.3299,-2.323 1.2846,-2.7508 1.3057,-0.5853 3.5533,-0.1596 4.9667,-0.1596 h 11.3771 39.6875 c 4.7699,0 9.8227,0.4686 14.5521,-0.1524 1.7272,-0.2267 3.4136,0.1482 4.59,-1.4467 0.9752,-1.3224 2.4926,-5.9002 0.6413,-6.9805 -1.2859,-0.7504 -3.2758,-0.4162 -4.7022,-0.4162 h -10.8479 -58.7375 c 3.184,-8.44 4.6564,-17.9655 6.8456,-26.7229 1.5962,-6.385 4.2606,-13.2877 4.7961,-19.8438 h 63.2354 10.5833 c 1.5897,0 3.5523,0.2993 5.0258,-0.4162 1.9468,-0.9451 2.9051,-4.6882 2.6069,-6.7262 -0.3153,-2.1548 -3.1443,-1.5889 -4.7222,-1.5889 h -14.8167 -50.0063 -12.7 c -1.5282,0 -3.7319,-0.4074 -4.9918,0.644 -1.4799,1.2348 -1.6772,3.9413 -2.1183,5.706 l -3.5068,14.023 c -4.499,17.9962 -9.0596,35.9778 -13.5588,53.975 l -7.9375,31.75 -2.0516,8.2021 c -0.2889,1.1588 -0.8403,2.7569 -0.336,3.9317 0.6892,1.6007 3.7526,1.0954 5.1321,1.0954 h 15.875 52.3875 c 6.2592,0 16.2367,2.1007 15.8491,-7.1438 -0.095,-2.2701 -2.5353,-2.1167 -4.2074,-2.1167 h -14.2875 -60.5896 m 334.1687,-108.0984 c -3.3708,0.5305 -6.2177,2.9165 -7.2019,6.2338 -1.2092,4.0892 1.5372,7.6309 5.879,7.0673 3.5004,-0.4548 6.3447,-2.8953 7.3528,-6.2735 1.27,-4.2482 -1.5981,-7.7251 -6.0299,-7.0276 m 413.5438,0.01 c -3.2333,0.5828 -6.0802,3.0657 -7.0274,6.2272 -1.2885,4.3083 1.7436,7.8304 6.2336,7.021 3.1433,-0.5664 5.9769,-2.8747 6.94,-5.9626 1.36,-4.3675 -1.4446,-8.1328 -6.1462,-7.2856 m -418.5709,28.3104 c -1.4552,0.1241 -3.5427,-0.2032 -4.7281,0.7858 -1.2726,1.0626 -1.4737,3.1317 -1.8521,4.6477 l -2.7781,11.1125 c -4.4344,17.7332 -8.9297,35.4515 -13.3614,53.1813 l -3.3073,13.2291 c -0.3387,1.3547 -1.405,3.6619 -0.6483,4.9901 0.7885,1.3811 3.1062,1.1456 4.4503,1.0848 1.3388,-0.061 2.667,-0.3996 3.437,-1.5875 2.4421,-3.7703 2.8495,-10.4511 3.937,-14.8061 l 13.4302,-53.7104 3.6354,-14.5521 c 0.5397,-2.1696 0.8017,-4.6329 -2.2146,-4.3752 m 414.0729,0.036 c -1.3943,0.031 -3.548,-0.2212 -4.7519,0.5673 -1.5108,0.9913 -1.7568,2.9527 -2.1616,4.5661 l -2.7782,11.1125 -13.0968,52.3875 c -1.2542,5.0245 -2.6035,10.033 -3.7624,15.0813 -0.5847,2.5479 -1.2859,5.1223 2.2093,5.2811 1.4763,0.069 3.4925,0.1349 4.6593,-0.934 1.2038,-1.106 1.4129,-3.1089 1.7886,-4.6117 0.8599,-3.4396 1.6774,-6.8898 2.5797,-10.3188 4.6355,-17.6583 8.8026,-35.4647 13.2318,-53.1812 l 3.7676,-15.0813 c 0.5107,-2.037 1.4843,-4.9392 -1.6854,-4.8688 m -619.1249,13.0709 c 0.5683,-2.753 1.3361,-5.4747 2.0179,-8.2021 0.2734,-1.0935 0.8935,-2.5638 0.4305,-3.6753 -0.5326,-1.2779 -2.1095,-1.0866 -3.2422,-1.0872 -2.9474,0 -4.8765,0.2212 -5.7211,3.4396 -2.8599,10.9011 -5.4694,21.8747 -8.2031,32.8084 l -5.2917,21.1666 -4.9599,19.8438 c -0.7281,2.913 -2.2217,6.5246 -2.2079,9.525 0.014,3.0718 5.9412,2.5453 7.5705,1.2091 1.6799,-1.3785 1.8793,-4.2518 2.3754,-6.2362 l 3.8365,-15.3458 c 1.8976,-7.5909 3.7637,-15.1898 5.7528,-22.7542 1.1534,-4.3868 2.0058,-8.8596 4.0066,-12.9646 6.3709,-13.0709 21.9501,-23.9985 36.9732,-21.8472 9.8869,1.4158 18.5835,9.3277 19.0396,19.7306 0.2538,5.7885 -1.5443,11.377 -2.9337,16.9333 -2.005,8.0221 -3.9475,16.0549 -5.9531,24.0771 l -2.9755,11.9062 c -0.4164,1.6669 -1.3819,3.8312 -1.2501,5.5563 0.2008,2.6246 5.4348,2.1828 7.0334,1.2858 2.4177,-1.3573 2.6649,-5.9769 3.2776,-8.4296 l 5.8209,-23.2833 c 2.7572,-11.0278 8.0108,-23.7556 5.2199,-35.1896 -0.8353,-3.4213 -2.4413,-6.2828 -4.2367,-9.2604 -8.6162,-14.2886 -28.6044,-14.682 -42.3569,-8.3849 -5.2052,2.3833 -9.4631,5.7986 -14.0229,9.1786 m 151.8708,57.6792 c -1.8997,6.7469 -3.1988,13.4117 -6.7284,19.5792 -8.8318,15.4305 -26.8816,26.5721 -44.8653,24.8258 -8.0177,-0.7779 -15.8523,-5.4372 -19.9885,-12.3904 -1.1883,-1.9976 -2.0733,-4.1355 -2.7588,-6.35 -0.3416,-1.1033 -0.4289,-2.749 -1.4037,-3.5084 -1.8319,-1.4235 -6.7659,0.7673 -7.8401,2.4765 -1.342,2.1378 0.2694,5.7838 1.0488,7.911 2.7289,7.4428 8.069,13.2371 15.0673,16.8752 17.2492,8.9614 38.7799,2.2304 53.1812,-9.1149 7.1623,-5.6436 13.4726,-13.171 17.2349,-21.5186 3.6195,-8.038 5.2097,-16.891 7.3369,-25.4 l 8.8636,-35.4541 5.1594,-20.6376 c 0.4312,-1.7229 2.2463,-5.7652 0.9339,-7.3241 -1.3467,-1.5995 -6.4955,-0.784 -7.6067,0.7212 -1.0901,1.4785 -1.2886,3.7957 -1.7251,5.5446 -0.9234,3.6857 -2.3707,7.5888 -2.6803,11.3771 -4.9397,-12.8762 -19.8437,-18.2563 -32.5437,-18.2563 -23.4527,0 -45.4316,17.9936 -52.8957,39.6876 -5.7807,16.801 -2.7369,35.7822 14.002,44.7965 3.1099,1.6749 6.5645,2.847 10.0541,3.4238 7.3792,1.217 15.0866,0.7593 22.225,-1.5664 9.8161,-3.1988 18.6082,-8.3767 25.9292,-15.6977 m 81.2271,-57.6792 c 0.5688,-2.7532 1.3361,-5.4747 2.0187,-8.2021 0.2726,-1.0932 0.8917,-2.5638 0.4287,-3.6753 -0.5319,-1.2779 -2.1088,-1.0866 -3.2412,-1.0872 -2.9474,0 -4.8763,0.2212 -5.7203,3.4396 -2.8601,10.9011 -5.4716,21.8747 -8.2047,32.8084 l -5.2917,21.1666 -4.9583,19.8438 c -0.7223,2.8839 -2.3468,6.5484 -2.2304,9.525 0.1164,2.9951 5.8102,2.5902 7.5327,1.3202 1.7409,-1.2805 1.9473,-4.4 2.4341,-6.3473 l 3.9688,-15.875 c 1.7224,-6.8845 3.4846,-13.7583 5.2282,-20.6375 1.2382,-4.8974 2.1722,-9.9827 4.4,-14.5521 6.3659,-13.0633 21.9604,-23.9969 36.9729,-21.8472 9.8874,1.4158 18.5843,9.3277 19.0394,19.7306 0.254,5.7885 -1.5452,11.377 -2.9343,16.9333 -2.0055,8.0221 -3.9475,16.0549 -5.9531,24.0771 l -2.9739,11.9062 c -0.418,1.6669 -1.3838,3.8312 -1.2515,5.5563 0.2011,2.6246 5.4346,2.1828 7.0326,1.2858 2.4183,-1.3573 2.667,-5.9769 3.2782,-8.4296 l 5.8209,-23.2833 c 2.7675,-11.0728 8.0274,-23.6929 5.2202,-35.1896 -0.8334,-3.4213 -2.4421,-6.2828 -4.236,-9.2604 -8.6122,-14.2833 -28.6041,-14.682 -42.3571,-8.3849 -5.2044,2.3833 -9.4642,5.7986 -14.0229,9.1786 m 85.9895,35.7188 h 38.3646 29.3688 c 2.8231,0 8.7021,1.1112 11.1019,-0.4604 3.1909,-2.0928 3.1856,-10.16 3.1856,-13.5625 0,-14.1507 -6.1569,-26.9005 -20.1084,-32.1667 -26.9425,-10.1693 -57.6897,9.9647 -67.4184,35.0771 -4.2757,11.0358 -5.3896,23.286 0.048,34.1312 10.8981,21.7408 40.2854,19.4601 58.1104,9.107 5.1117,-2.9686 9.9695,-6.8977 13.9991,-11.2236 1.1615,-1.2462 3.5957,-3.1406 3.392,-5.0271 -0.2884,-2.6644 -4.4001,-4.2122 -6.5432,-3.0268 -2.413,1.3361 -4.355,4.2862 -6.35,6.1912 -3.0506,2.9157 -6.5828,5.2731 -10.3187,7.2125 -15.6052,8.1016 -38.0233,6.8633 -45.3893,-11.6998 -1.9315,-4.8657 -1.5478,-9.4801 -1.442,-14.5521 m 109.0083,0 h 38.3646 29.3688 c 2.8178,0 8.7101,1.1139 11.1019,-0.4604 1.3282,-0.8758 1.6722,-2.585 1.9685,-4.0375 0.6482,-3.1697 1.2171,-6.2812 1.2171,-9.525 0,-14.1724 -6.1648,-26.9039 -20.1084,-32.1667 -25.8101,-9.7417 -54.2448,8.2314 -65.6828,31.1083 -5.8129,11.6285 -7.8343,26.17 -1.7171,38.1 11.0913,21.635 40.1664,19.5475 58.1395,9.107 5.1118,-2.9686 9.9695,-6.8977 13.9991,-11.2236 1.1616,-1.2462 3.5957,-3.1406 3.392,-5.0271 -0.2858,-2.63 -4.4185,-4.2175 -6.5405,-3.0268 -2.1987,1.2329 -4.0323,3.9026 -5.8235,5.6726 -2.6273,2.5929 -5.7547,4.9027 -8.9958,6.6755 -14.1843,7.7628 -33.5783,9.4324 -44.2145,-5.088 -1.741,-2.3759 -3.0269,-5.1038 -3.8259,-7.9375 -1.1351,-4.0164 -0.9657,-8.0671 -0.643,-12.1708 m 117.2105,-35.7188 c 0.4471,-3.3229 3.3073,-8.3775 2.4844,-11.6366 -0.6297,-2.4916 -6.9268,-1.6222 -8.12,0.02 -1.188,1.6341 -1.3891,4.3937 -1.8706,6.3252 l -3.3073,13.2291 -11.6417,46.5667 -3.9053,15.6104 c -0.3915,1.5717 -1.7092,4.3815 0.1958,5.4055 1.9315,1.0371 5.887,0.6641 7.1941,-1.1827 0.9154,-1.2938 1.098,-3.2412 1.4737,-4.7519 l 2.5823,-10.3188 c 2.2278,-8.9112 4.408,-17.8382 6.7443,-26.7229 1.3811,-5.2626 2.3098,-10.7455 4.8603,-15.6104 3.8603,-7.366 10.2791,-13.4456 17.5975,-17.3332 5.4319,-2.8847 12.0862,-4.5593 18.2562,-3.757 2.8813,0.3746 6.4479,2.6527 9.2605,2.2471 2.3627,-0.3408 5.535,-4.6223 4.9397,-7.0615 -0.2963,-1.2033 -1.8177,-1.6425 -2.8231,-2.0659 -2.8786,-1.2112 -6.4029,-1.9121 -9.525,-1.9272 -13.5228,-0.065 -23.8813,4.6199 -34.3958,12.9643 m 101.6,0 c 0.3598,-2.6654 1.1668,-5.3287 1.8177,-7.9375 0.2963,-1.1824 0.889,-2.7479 0.4048,-3.9531 -0.5292,-1.311 -2.1352,-1.074 -3.2809,-1.074 -3.548,-2e-4 -4.8286,0.657 -5.7229,4.2334 l -8.1333,32.5437 -5.2281,20.9021 c -1.5875,6.3553 -3.2385,12.6947 -4.826,19.05 -0.7515,3.0057 -1.9236,6.1754 -2.2384,9.2604 -0.3757,3.6857 5.4213,3.7862 7.5988,2.0029 1.6828,-1.3784 1.8786,-4.5111 2.376,-6.5008 l 3.9687,-15.875 5.2282,-20.9021 c 1.2065,-4.8339 2.1854,-9.7996 4.4291,-14.2875 6.9215,-13.8427 23.3336,-24.3636 39.0604,-21.2174 9.6309,1.9264 16.5153,10.7524 16.9228,20.4237 0.2143,5.0519 -1.5901,10.2367 -2.8019,15.0812 l -6.35,25.4 -2.8417,11.3771 c -0.418,1.6695 -1.3705,3.8233 -1.1747,5.5563 0.2937,2.6273 5.4134,2.2066 7.0829,1.2806 2.2569,-1.2595 2.5188,-5.6251 3.0877,-7.8952 l 5.6197,-22.4896 c 2.9316,-11.7237 8.6334,-25.4474 5.2123,-37.5708 -0.8546,-3.0282 -2.3204,-5.5341 -3.9185,-8.2021 -8.4084,-14.0179 -27.8421,-14.6206 -41.4761,-8.7649 -5.4953,2.3604 -10.1996,5.8124 -14.8166,9.5586 m 151.6062,57.9438 c -1.4367,6.9559 -3.3469,13.9673 -6.9982,20.1083 -8.9138,14.9781 -26.7176,25.744 -44.3309,24.0321 -8.2365,-0.799 -16.0073,-5.5165 -20.2539,-12.655 -1.0689,-1.7965 -2.0002,-3.8047 -2.5664,-5.8208 -0.3308,-1.1721 -0.3546,-2.9395 -1.3679,-3.773 -1.8283,-1.5028 -7.0935,0.8996 -8.0063,2.7199 -1.1298,2.2516 0.5291,6.0431 1.3493,8.1968 2.9237,7.6756 9.1758,14.2187 16.8222,17.3435 19.1109,7.8105 40.4734,-0.2461 55.0334,-13.4197 12.6973,-11.4882 16.4915,-26.371 20.4708,-42.2884 l 9.525,-38.1 4.8948,-19.5791 c 0.426,-1.6976 2.1643,-5.5195 0.8969,-7.0596 -1.315,-1.5984 -6.6225,-0.8033 -7.7073,0.7373 -1.0636,1.5145 -1.2806,3.7637 -1.7198,5.5285 -0.8996,3.5912 -2.2463,7.4232 -2.5479,11.1125 -8.6836,-16.2028 -27.8474,-21.0497 -44.7146,-16.2909 -19.0685,5.3798 -35.0838,20.0295 -41.185,39.0451 -5.2044,16.2295 -2.1088,35.5679 14.4621,43.8547 3.7862,1.8944 7.7338,2.9818 11.9062,3.5771 6.9136,0.9843 14.2717,0.1905 20.9021,-2.0108 9.3848,-3.1168 18.1187,-8.2471 25.1354,-15.2585 m -406.6645,-30.9563 h -70.6438 c 5.5139,-13.2603 16.6502,-24.5996 30.4271,-29.2322 14.8987,-5.0101 32.8639,-1.0435 38.8779,14.9447 1.7991,4.7879 1.352,9.3367 1.3388,14.2875 m -264.848,-31.1451 c 14.0759,-1.7288 28.202,5.5822 31.6178,20.0326 1.2065,5.1099 0.7355,10.5569 -0.5239,15.6105 -4.3789,17.6 -21.2408,33.2845 -39.5605,35.1446 -6.5061,0.6614 -13.1128,0.1746 -19.05,-2.8152 -12.7593,-6.4241 -16.1028,-21.7223 -12.164,-34.4461 5.3809,-17.3845 21.4932,-31.2925 39.6806,-33.5264 m 373.8563,31.1451 h -70.6438 c 5.4293,-13.0593 16.518,-24.6523 30.1625,-29.1705 15.1263,-5.0089 33.1973,-1.2163 39.1451,15.1476 1.704,4.6953 1.3494,9.1739 1.3362,14.0229 m 273.05,-31.1451 c 13.8641,-1.6584 28.0485,5.438 31.4219,19.7681 1.2303,5.2244 0.8546,10.7024 -0.4392,15.875 -4.4265,17.7112 -21.3122,33.2766 -39.714,35.1446 -5.4901,0.5582 -11.1918,0.373 -16.4041,-1.6643 -15.4702,-6.0536 -18.9125,-23.4447 -14.0018,-37.7137 5.6568,-16.4409 21.9393,-29.3529 39.1372,-31.4097 m -228.6,4.1576 -0.2646,0.2646 0.2646,-0.2646 m 101.6,0 -0.2646,0.2646 z" id="path693" transform="matrix(4.4302516,0,0,4.4302516,-3199.6599,-8011.0243)"></path> </g> <style type="text/css" id="style2020">.st0{fill:#8D8E90;}.st1{fill:#C1C2C4;}.st2{fill:#606467;}.st3{fill:#FE0000;}.st4{fill:#EBEBEB;}.st5{fill:#FEFEFE;}</style> <metadata id="metadata2160"> <rdf:rdf> <cc:work rdf:about=""> <dc:title>X Engineering</dc:title> <dc:format>image/svg+xml</dc:format> <dc:type rdf:resource="http://purl.org/dc/dcmitype/StillImage"></dc:type> </cc:work> </rdf:rdf> </metadata></svg></a></label>';
		} else {
			return $html;
		}
	}

	/**
	 * @param string $post_type
	 * @param WP_Post $post
	 */
	public function _action_create_post_meta_boxes( $post_type, $post = null ) {
		if ( 'comment' === $post_type || ( isset( $_GET['vc_action'] ) && $_GET['vc_action'] === 'vc_inline' ) ) {
			/**
			 * 1. https://github.com/ThemeFuse/Unyson/issues/3052
			 * 2. This is wrong, comment is not a post(type) it is stored in a separate db table and has a separate meta (wp_comments and wp_commentmeta)
			 */
			return;
		}

		$options = fw()->theme->get_post_options( $post_type );

		if ( empty( $options ) ) {
			return;
		}

		$collected = array();

		fw_collect_options( $collected, $options, array(
			'limit_option_types'    => false,
			'limit_container_types' => false,
			'limit_level'           => 1,
		) );

		if ( empty( $collected ) ) {
			return;
		}

		$values = fw_get_db_post_option( $post->ID );

		foreach ( $collected as $id => &$option ) {

			if ( isset( $option['options'] ) && ( $option['type'] === 'box' || $option['type'] === 'group' ) ) {
				$context  = isset( $option['context'] ) ? $option['context'] : 'normal';
				$priority = isset( $option['priority'] ) ? $option['priority'] : 'default';

				add_meta_box(
					"fw-options-box-{$id}",
					empty( $option['title'] ) ? ' ' : $option['title'],
					array( $this, 'render_meta_box' ),
					$post_type,
					$context,
					$priority,
					array( 'fw_box_html' => $this->render_options( $option['options'], $values ) )
				);
			} else { // this is not a box, wrap it in auto-generated box
				add_meta_box(
					'fw-options-box:auto-generated:' . time() . ':' . fw_unique_increment(),
					' ',
					array( $this, 'render_meta_box' ),
					$post_type,
					'normal',
					'default',
					$this->render_options( array( $id => $option ), $values )
				);
			}
		}
	}

	public function render_meta_box( $post, $args ) {
		if ( empty( $args['args'] ) ) {
			return;
		}

		if ( isset( $args['args']['fw_box_html'] ) ) {
			echo $args['args']['fw_box_html'];
		} elseif ( ! is_array( $args['args'] ) ) {
			echo $args['args'];
		}
	}

	/**
	 * @param object $term
	 */
	public function _action_create_taxonomy_options( $term ) {
		$options = fw()->theme->get_taxonomy_options( $term->taxonomy );

		if ( empty( $options ) ) {
			return;
		}

		$collected = array();

		fw_collect_options( $collected, $options, array(
			'limit_option_types' => false,
			'limit_container_types' => false,
			'limit_level' => 1,
		) );

		if ( empty( $collected ) ) {
			return;
		}

		$values = fw_get_db_term_option( $term->term_id, $term->taxonomy );

		// fixes word_press style: .form-field input { width: 95% }
		echo '<style type="text/css">.fw-option-type-radio input, .fw-option-type-checkbox input { width: auto; }</style>';

		do_action( 'fw_backend_options_render:taxonomy:before' );
		echo $this->render_options( $collected, $values, array(), 'taxonomy' );
		do_action( 'fw_backend_options_render:taxonomy:after' );
	}

	/**
	 * @param string $taxonomy
	 */
	public function _action_create_add_taxonomy_options( $taxonomy ) {
		$options = fw()->theme->get_taxonomy_options( $taxonomy );

		if ( empty( $options ) ) {
			return;
		}

		$collected = array();

		fw_collect_options( $collected, $options, array(
			'limit_option_types'    => false,
			'limit_container_types' => false,
			'limit_level'           => 1,
		) );

		if ( empty( $collected ) ) {
			return;
		}

		// fixes word_press style: .form-field input { width: 95% }
		echo '<style type="text/css">.fw-option-type-radio input, .fw-option-type-checkbox input { width: auto; }</style>';

		do_action( 'fw_backend_options_render:taxonomy:before' );

		echo '<div class="fw-force-xs">';
		echo $this->render_options( $collected, array(), array(), 'taxonomy' );
		echo '</div>';

		do_action( 'fw_backend_options_render:taxonomy:after' );

		echo '<script type="text/javascript">'
			.'jQuery(function($){'
			.'    $("#submit").on("click", function(){'
			.'        $("html, body").animate({ scrollTop: $("#col-left").offset().top });'
			.'    });'
			.'});'
			.'</script>';
	}

	public function _action_init() {
		$current_edit_taxonomy = $this->get_current_edit_taxonomy();

		if ( $current_edit_taxonomy['taxonomy'] ) {
			add_action(
				$current_edit_taxonomy['taxonomy'] . '_edit_form',
				array( $this, '_action_create_taxonomy_options' )
			);

			if (fw()->theme->get_config('taxonomy_create_has_unyson_options', true)) {
				add_action(
					$current_edit_taxonomy['taxonomy'] . '_add_form_fields',
					array( $this, '_action_create_add_taxonomy_options' )
				);
			}
		}

		if ( ! empty( $_POST ) ) {
			// is form submit
			add_action( 'edited_term', array( $this, '_action_term_edit' ), 10, 3 );

			if ($current_edit_taxonomy['taxonomy']) {
				add_action(
					'create_' . $current_edit_taxonomy['taxonomy'],
					array($this, '_action_save_taxonomy_fields')
				);
			}
		}
	}

	/**
	 * Save meta from $_POST to fw options (post meta)
	 * @param int $post_id
	 * @param WP_Post $post
	 * @param bool $update
	 */
	public function _action_save_post( $post_id, $post, $update ) {

		if (
			isset($_POST['post_ID'])
			&&
			intval($_POST['post_ID']) === intval($post_id)
			&&
			!empty($_POST[ $this->get_options_name_attr_prefix() ]) // this happens on Quick Edit
		) {
			/**
			 * This happens on regular post form submit
			 * All data from $_POST belongs this $post
			 * so we save them in its post meta
			 */

			static $post_options_save_happened = false;
			if ($post_options_save_happened) {
				/**
				 * Prevent multiple options save for same post
				 * It can happen from a recursion or wp_update_post() for same post id
				 */
				return;
			} else {
				$post_options_save_happened = true;
			}

			$old_values = (array)fw_get_db_post_option($post_id);

			fw_set_db_post_option(
				$post_id,
				null,
				fw_get_options_values_from_input(
					fw()->theme->get_post_options($post->post_type)
				)
			);

			/**
			 * @deprecated
			 * Use the 'fw_post_options_update' action
			 */
			do_action( 'fw_save_post_options', $post_id, $post, $old_values );
		} elseif ($original_post_id = wp_is_post_autosave( $post_id )) {

			do {
				$parent = get_post($post->post_parent);

				if ( ! $parent instanceof WP_Post ) {
					break;
				}

				if ( isset($_POST['post_ID']) && intval($_POST['post_ID']) === intval($parent->ID) ) {

				} else {
					break;
				}

				if (empty($_POST[ $this->get_options_name_attr_prefix() ])) {
					// this happens on Quick Edit
					break;
				}

				fw_set_db_post_option(
					$post->ID,
					null,
					fw_get_options_values_from_input(
						fw()->theme->get_post_options($parent->post_type)
					)
				);
			} while(false);
		} elseif ($original_post_id = wp_is_post_revision( $post_id )) {

			/**
			 * Do nothing, the
			 * - '_wp_put_post_revision'
			 * - 'wp_restore_post_revision'
			 * actions will handle this
			 */
		}  else {
			/**
			 * This happens on:
			 * - post add (auto-draft): do nothing
			 * - revision restore: do nothing, that is handled by the 'wp_restore_post_revision' action
			 */
		}
	}

	/**
	 * @param $revision_id
	 */
	public function _action__wp_put_post_revision( $revision_id ) {
		/**
		 * Copy options meta from post to revision
		 */
		fw_set_db_post_option(
			$revision_id,
			null,
			(array) fw_get_db_post_option(
				wp_is_post_revision( $revision_id ),
				null,
				array()
			)
		);
	}

	/**
	 * @param $post_id
	 * @param $revision_id
	 */
	public function _action_restore_post_revision($post_id, $revision_id)
	{
		/**
		 * Copy options meta from revision to post
		 */
		fw_set_db_post_option(
			$post_id,
			null,
			(array)fw_get_db_post_option($revision_id, null, array())
		);
	}

	/**
	 * Update all post meta `fw_option:<option-id>` with values from post options that has the 'save-in-separate-meta' parameter
	 *
	 * @param int $post_id
	 *
	 * @return bool
	 * @deprecated since 2.5.0
	 */
	public function _sync_post_separate_meta( $post_id ) {
		if ( ! ( $post_type = get_post_type( $post_id ) ) ) {
			return false;
		}

		$meta_prefix = 'fw_option:';
		$only_options = fw_extract_only_options( fw()->theme->get_post_options( $post_type ) );
		$separate_meta_options = array();

		// Collect all options that needs to be saved in separate meta
		{
			$options_values = fw_get_db_post_option( $post_id );

			foreach ($only_options as $option_id => $option) {
				if (
					isset( $option['save-in-separate-meta'] )
					&&
					$option['save-in-separate-meta']
					&&
					array_key_exists( $option_id, $options_values )
				) {
					if (defined('WP_DEBUG') && WP_DEBUG) {
						FW_Flash_Messages::add(
							'save-in-separate-meta:deprecated',
							'<p>The <code>save-in-separate-meta</code> option parameter is <strong>deprecated</strong>.</p>'
							.'<p>Please replace</p>'
							.'<pre>\'save-in-separate-meta\' => true</pre>'
							.'<p>with</p>'
							.'<pre>\'fw-storage\' => array('
							."\n	'type' => 'post-meta',"
							."\n	'post-meta' => 'fw_option:{your-option-id}',"
							."\n)</pre>"
							.'<p>in <code>{theme}'. fw_get_framework_customizations_dir_rel_path('/theme/options/posts/'. $post_type .'.php') .'</code></p>'
							.'<p><a href="'. esc_attr('http://manual.unyson.io/en/latest/options/storage.html#content') .'" target="_blank">'. esc_html__('Info about fw-storage', 'fw') .'</a></p>',
							'warning'
						);
					}

					$separate_meta_options[ $meta_prefix . $option_id ] = $options_values[ $option_id ];
				}
			}

			unset( $options_values );
		}

		// Delete meta that starts with $meta_prefix
		{
			/** @var wpdb $wpdb */
			global $wpdb;

			foreach (
				$wpdb->get_results(
					$wpdb->prepare(
						"SELECT meta_key " .
						"FROM {$wpdb->postmeta} " .
						"WHERE meta_key LIKE %s AND post_id = %d",
						$wpdb->esc_like( $meta_prefix ) . '%',
						$post_id
					)
				) as $row
			) {
				if (
					array_key_exists( $row->meta_key, $separate_meta_options )
					||
					( // skip options containing 'fw-storage'
						($option_id = substr($row->meta_key, 10))
						&&
						isset($only_options[$option_id]['fw-storage'])
					)
				) {
					/**
					 * This meta exists and will be updated below.
					 * Do not delete for performance reasons, instead of delete->insert will be performed only update
					 */
					continue;
				} else {
					// this option does not exist anymore
					delete_post_meta( $post_id, $row->meta_key );
				}
			}
		}

		foreach ( $separate_meta_options as $meta_key => $option_value ) {
			fw_update_post_meta($post_id, $meta_key, $option_value );
		}

		return true;
	}

	/**
	 * @param int $term_id
	 */
	public function _action_save_taxonomy_fields( $term_id ) {
		if (
			isset( $_POST['action'] )
			&&
			'add-tag' === $_POST['action']
			&&
			isset( $_POST['taxonomy'] )
			&&
			($taxonomy = get_taxonomy( $_POST['taxonomy'] ))
			&&
			current_user_can($taxonomy->cap->edit_terms)
		) { /* ok */ } else { return; }

		$options = fw()->theme->get_taxonomy_options( $taxonomy->name );
		if ( empty( $options ) ) {
			return;
		}

		fw_set_db_term_option(
			$term_id,
			$taxonomy->name,
			null,
			fw_get_options_values_from_input($options)
		);

		do_action( 'fw_save_term_options', $term_id, $taxonomy->name, array() );
	}

	public function _action_term_edit( $term_id, $tt_id, $taxonomy ) {
		if (
			isset( $_POST['action'] )
			&&
			'editedtag' === $_POST['action']
			&&
			isset( $_POST['taxonomy'] )
			&&
			($taxonomy = get_taxonomy( $_POST['taxonomy'] ))
			&&
			current_user_can($taxonomy->cap->edit_terms)
		) { /* ok */ } else { return; }

		if (intval(FW_Request::POST('tag_ID')) != $term_id) {
			// the $_POST values belongs to another term, do not save them into this one
			return;
		}

		$options = fw()->theme->get_taxonomy_options( $taxonomy->name );
		if ( empty( $options ) ) {
			return;
		}

		$old_values = (array) fw_get_db_term_option( $term_id, $taxonomy->name );

		fw_set_db_term_option(
			$term_id,
			$taxonomy->name,
			null,
			fw_get_options_values_from_input($options)
		);

		do_action( 'fw_save_term_options', $term_id, $taxonomy->name, $old_values );
	}

	public function _action_admin_register_scripts() {
		$this->register_static();
	}

	public function _action_admin_enqueue_scripts() {
		/**
		 * Enqueue settings options static in <head>
		 * @see FW_Settings_Form_Theme::_action_admin_enqueue_scripts()
		 */

		/**
		 * Enqueue post options static in <head>
		 */
		{
			if ( 'post' === get_current_screen()->base && get_the_ID() ) {
				fw()->backend->enqueue_options_static(
					fw()->theme->get_post_options( get_post_type() )
				);

				do_action( 'fw_admin_enqueue_scripts:post', get_post() );
			}
		}

		/**
		 * Enqueue term options static in <head>
		 */
		{
			if (
				in_array(get_current_screen()->base, array('edit-tags', 'term'), true)
				&&
				get_current_screen()->taxonomy
			) {
				fw()->backend->enqueue_options_static(
					fw()->theme->get_taxonomy_options( get_current_screen()->taxonomy )
				);

				do_action( 'fw_admin_enqueue_scripts:term', get_current_screen()->taxonomy );
			}
		}
	}

	/**
	 * Render options html from input json
	 *
	 * POST vars:
	 * - options: '[{option_id: {...}}, {option_id: {...}}, ...]'                  // Required // String JSON
	 * - values:  {option_id: value, option_id: {...}, ...}                        // Optional // Object
	 * - data:    {id_prefix: 'fw_options-a-b-', name_prefix: 'fw_options[a][b]'}  // Optional // Object
	 */
	public function _action_ajax_options_render() {
		// options
		{
			if ( ! isset( $_POST['options'] ) ) {
				wp_send_json_error( array(
					'message' => 'No options'
				) );
			}

			$options = json_decode( FW_Request::POST( 'options' ), true );

			if ( ! $options ) {
				wp_send_json_error( array(
					'message' => 'Wrong options'
				) );
			}
		}

		// values
		{
			if ( isset( $_POST['values'] ) ) {
				$values = FW_Request::POST( 'values' );

				if (is_string($values)) {
					$values = json_decode($values, true);
				}
			} else {
				$values = array();
			}

			$filtered_values = apply_filters(
				'fw:ajax_options_render:values',
				null,
				$options,
				$values
			);

			$values = $filtered_values ? $filtered_values : array_intersect_key(
				$values,
				fw_extract_only_options( $options )
			);
		}

		// data
		{
			if ( isset( $_POST['data'] ) ) {
				$data = FW_Request::POST( 'data' );
			} else {
				$data = array();
			}
		}

		wp_send_json_success( array(
			'html' => fw()->backend->render_options( $options, $values, $data ),
			/** @since 2.6.1 */
			'default_values' => fw_get_options_values_from_input($options, array()),
		) );
	}

	/**
	 * Get options values from html generated with 'fw_backend_options_render' ajax action
	 *
	 * POST vars:
	 * - options: '[{option_id: {...}}, {option_id: {...}}, ...]' // Required // String JSON
	 * - fw_options... // Use a jQuery "ajax form submit" to emulate real form submit
	 *
	 * Tip: Inside form html, add: <input type="hidden" name="options" value="[...json...]">
	 */
	public function _action_ajax_options_get_values() {
		// options
		{
			if ( ! isset( $_POST['options'] ) ) {
				wp_send_json_error( array(
					'message' => 'No options'
				) );
			}

			$options = FW_Request::POST( 'options' );

			if (is_string( $options )) {
				$options = json_decode( FW_Request::POST( 'options' ), true );
			}

			if ( ! $options ) {
				wp_send_json_error( array(
					'message' => 'Wrong options'
				) );
			}
		}

		// name_prefix
		{
			if ( isset( $_POST['name_prefix'] ) ) {
				$name_prefix = FW_Request::POST( 'name_prefix' );
			} else {
				$name_prefix = $this->get_options_name_attr_prefix();
			}
		}

		wp_send_json_success( array(
			'values' => fw_get_options_values_from_input(
				$options,
				FW_Request::POST( fw_html_attr_name_to_array_multi_key( $name_prefix ), array() )
			)
		) );
	}

	/**
	 * Get options values from html generated with 'fw_backend_options_render' ajax action
	 *
	 * POST vars:
	 * - options: '[{option_id: {...}}, {option_id: {...}}, ...]' // Required // String JSON
	 * - values: {option_id: {...}}
	 *
	 * Tip: Inside form html, add: <input type="hidden" name="options" value="[...json...]">
	 */
	public function _action_ajax_options_get_values_json() {
		// options
		{
			if ( ! isset( $_POST['options'] ) ) {
				wp_send_json_error( array(
					'message' => 'No options'
				) );
			}

			$options = FW_Request::POST( 'options' );

			if (is_string( $options )) {
				$options = json_decode( FW_Request::POST( 'options' ), true );
			}

			if ( ! $options ) {
				wp_send_json_error( array(
					'message' => 'Wrong options'
				) );
			}
		}

		// values
		{
			if ( ! isset( $_POST['values'] ) ) {
				wp_send_json_error( array(
					'message' => 'No values'
				) );
			}

			$values = FW_Request::POST( 'values' );

			if (is_string( $values )) {
				$values = json_decode( FW_Request::POST( 'values' ), true );
			}

			if (! is_array($values)) {
				if ( ! $values ) {
					wp_send_json_error(array(
						'message' => 'Wrong values'
					));
				}
			}
		}

		wp_send_json_success( array(
			'values' => fw_get_options_values_from_input(
				$options,
				$values
			)
		) );
	}

	/**
	 * Render options array and return the generated HTML
	 *
	 * @param array $options
	 * @param array $values Correct values returned by fw_get_options_values_from_input()
	 * @param array $options_data {id_prefix => ..., name_prefix => ...}
	 * @param string $design
	 *
	 * @return string HTML
	 */
	public function render_options( $options, $values = array(), $options_data = array(), $design = null ) {
		if (empty($design)) {
			$design = $this->default_render_design;
		}

		if (
			!doing_action('admin_enqueue_scripts')
			&&
			!did_action('admin_enqueue_scripts')
		) {
			/**
			 * Do not wp_enqueue/register_...() because at this point not all handles has been registered
			 * and maybe they are used in dependencies in handles that are going to be enqueued.
			 * So as a result some handles will not be equeued because of not registered dependecies.
			 */
		} else {
			/**
			 * register scripts and styles
			 * in case if this method is called before enqueue_scripts action
			 * and option types has some of these in their dependencies
			 */
			$this->register_static();

			wp_enqueue_media();
			wp_enqueue_style( 'fw-backend-options' );
			wp_enqueue_script( 'fw-backend-options' );
		}

		$collected = array();

		fw_collect_options( $collected, $options, array(
			'limit_option_types' => false,
			'limit_container_types' => false,
			'limit_level' => 1,
			'info_wrapper' => true,
		) );

		if ( empty( $collected ) ) {
			return false;
		}

		$html = '';

		$option = reset( $collected );

		$collected_type = array(
			'group' => $option['group'],
			'type'  => $option['option']['type'],
		);
		$collected_type_options = array(
			$option['id'] => &$option['option']
		);

		while ( $collected_type_options ) {
			$option = next( $collected );

			if ( $option ) {
				if (
					$option['group'] === $collected_type['group']
					&&
					$option['option']['type'] === $collected_type['type']
				) {
					$collected_type_options[ $option['id'] ] = &$option['option'];
					continue;
				}
			}

			switch ( $collected_type['group'] ) {
				case 'container':
					if ($design === 'taxonomy') {
						$html .= fw_render_view(
							fw_get_framework_directory('/views/backend-container-design-'. $design .'.php'),
							array(
								'type' => $collected_type['type'],
								'html' => $this->container_type($collected_type['type'])->render(
									$collected_type_options, $values, $options_data
								),
							)
						);
					} else {
						$html .= $this->container_type($collected_type['type'])->render(
							$collected_type_options, $values, $options_data
						);
					}
					break;
				case 'option':
					foreach ( $collected_type_options as $id => &$_option ) {
						$data = $options_data; // do not change directly to not affect next loops

						$maybe_future_value = apply_filters(
							'fw:render_options:option_value',
							null,
							$values,
							$_option,
							$id
						);

						if (! $maybe_future_value) {
							$maybe_future_value = isset( $values[ $id ] ) ? $values[ $id ] : null;
						}

						$data['value'] = $maybe_future_value;

						$html .= $this->render_option(
							$id,
							$_option,
							$data,
							$design
						);
					}
					unset($_option);
					break;
				default:
					$html .= '<p><em>' . __( 'Unknown collected group', 'fw' ) . ': ' . $collected_type['group'] . '</em></p>';
			}

			unset( $collected_type, $collected_type_options );

			if ( $option ) {
				$collected_type = array(
					'group' => $option['group'],
					'type'  => $option['option']['type'],
				);
				$collected_type_options = array(
					$option['id'] => &$option['option']
				);
			} else {
				$collected_type_options = array();
			}
		}

		return $html;
	}

	/**
	 * Enqueue options static
	 *
	 * Useful when you have dynamic options html on the page (for e.g. options modal)
	 * and in order to initialize that html properly, the option types scripts styles must be enqueued on the page
	 *
	 * @param array $options
	 */
	public function enqueue_options_static( $options ) {
		static $static_enqueue = true;

		if (
			!doing_action('admin_enqueue_scripts')
			&&
			!did_action('admin_enqueue_scripts')
		) {
			/**
			 * Do not wp_enqueue/register_...() because at this point not all handles has been registered
			 * and maybe they are used in dependencies in handles that are going to be enqueued.
			 * So as a result some handles will not be equeued because of not registered dependecies.
			 */
			return;
		} else {
			/**
			 * register scripts and styles
			 * in case if this method is called before enqueue_scripts action
			 * and option types has some of these in their dependencies
			 */
			if ($static_enqueue) {
				$this->register_static();

				wp_enqueue_media();
				wp_enqueue_style( 'fw-backend-options' );
				wp_enqueue_script( 'fw-backend-options' );

				$static_enqueue = false;
			}
		}

		$collected = array();

		fw_collect_options( $collected, $options, array(
			'limit_option_types' => false,
			'limit_container_types' => false,
			'limit_level' => 0,
			'callback' => array(__CLASS__, '_callback_fw_collect_options_enqueue_static'),
		) );

		unset($collected);
	}

	/**
	 * @internal
	 * @param array $data
	 */
	public static function _callback_fw_collect_options_enqueue_static($data) {
		if ($data['group'] === 'option') {
			fw()->backend->option_type($data['option']['type'])->enqueue_static($data['id'], $data['option']);
		} elseif ($data['group'] === 'container') {
			fw()->backend->container_type($data['option']['type'])->enqueue_static($data['id'], $data['option']);
		}
	}

	/**
	 * Render option enclosed in backend design
	 *
	 * @param string $id
	 * @param array $option
	 * @param array $data
	 * @param string $design default or taxonomy
	 *
	 * @return string
	 */
	public function render_option( $id, $option, $data = array(), $design = null ) {

		$maybe_forced_design = fw()->backend->option_type( $option['type'] )->get_forced_render_design();

		if (empty($design)) {
			$design = $this->default_render_design;
		}

		if ($maybe_forced_design) {
			$design = $maybe_forced_design;
		}

		if (
			!doing_action('admin_enqueue_scripts')
			&&
			!did_action('admin_enqueue_scripts')
		) {
			/**
			 * Do not wp_enqueue/register_...() because at this point not all handles has been registered
			 * and maybe they are used in dependencies in handles that are going to be enqueued.
			 * So as a result some handles will not be equeued because of not registered dependecies.
			 */
		} else {
			$this->register_static();
		}


		if ( ! in_array( $design, $this->available_render_designs ) ) {
			trigger_error( 'Invalid render design specified: ' . $design, E_USER_WARNING );
			$design = 'post';
		}

		if ( ! isset( $data['id_prefix'] ) ) {
			$data['id_prefix'] = $this->get_options_id_attr_prefix();
		}

		$data = apply_filters(
			'fw:backend:option-render:data',
			$data
		);

		return fw_render_view(fw_get_framework_directory('/views/backend-option-design-'. $design .'.php'), array(
			'id'     => $id,
			'option' => $option,
			'data'   => $data,
		) );
	}

	/**
	 * Render a meta box
	 *
	 * @param string $id
	 * @param string $title
	 * @param string $content HTML
	 * @param array $other Optional elements
	 *
	 * @return string Generated meta box html
	 */
	public function render_box( $id, $title, $content, $other = array() ) {
		if ( ! function_exists( 'add_meta_box' ) ) {
			trigger_error( 'Try call this method later (\'admin_init\' action), add_meta_box() function does not exists yet.',
				E_USER_WARNING );

			return '';
		}

		$other = array_merge( array(
			'html_before_title' => false,
			'html_after_title'  => false,
			'attr'              => array(),
		), $other );

		{
			$placeholders = array(
				'id'      => '{{meta_box_id}}',
				'title'   => '{{meta_box_title}}',
				'content' => '{{meta_box_content}}',
			);

			// other placeholders
			{
				$placeholders['html_before_title'] = '{{meta_box_html_before_title}}';
				$placeholders['html_after_title']  = '{{meta_box_html_after_title}}';
				$placeholders['attr']              = '{{meta_box_attr}}';
				$placeholders['attr_class']        = '{{meta_box_attr_class}}';
			}
		}

		$cache_key = 'fw_meta_box_template';

		try {
			$meta_box_template = FW_Cache::get( $cache_key );
		} catch ( FW_Cache_Not_Found_Exception $e ) {
			$temp_screen_id = 'fw-temp-meta-box-screen-id-' . fw_unique_increment();
			$context        = 'normal';

			add_meta_box(
				$placeholders['id'],
				$placeholders['title'],
				array( $this, 'render_meta_box' ),
				$temp_screen_id,
				$context,
				'default',
				$placeholders['content']
			);

			ob_start();

			do_meta_boxes( $temp_screen_id, $context, null );

			$meta_box_template = ob_get_clean();

			remove_meta_box( $id, $temp_screen_id, $context );

			// remove wrapper div, leave only meta box div
			{
				// <div ...>
				{
					$meta_box_template = str_replace(
						'<div id="' . $context . '-sortables" class="meta-box-sortables">',
						'',
						$meta_box_template
					);
				}

				// </div>
				{
					$meta_box_template = explode( '</div>', $meta_box_template );
					array_pop( $meta_box_template );
					$meta_box_template = implode( '</div>', $meta_box_template );
				}
			}

			// add 'fw-postbox' class and some attr related placeholders
			$meta_box_template = str_replace(
				'class="postbox ',
				$placeholders['attr'] . ' class="postbox fw-postbox' . $placeholders['attr_class'],
				$meta_box_template
			);

			// add html_before|after_title placeholders
			{
				$meta_box_template = str_replace(
					'<h2 class="hndle">' . $placeholders['title'] . '</h2>',

					/**
					 * used <small> not <span> because there is a lot of css and js
					 * that thinks inside <h2 class="hndle"> there is only one <span>
					 * so do not brake their logic
					 */
					'<h2 class="hndle">' .
					'<small class="fw-html-before-title">' . $placeholders['html_before_title'] . '</small>' .
					'<span>' . $placeholders['title'] . '</span>' .
					'<small class="fw-html-after-title">' . $placeholders['html_after_title'] . '</small>' .
					'</h2>',

					$meta_box_template
				);
			}

			FW_Cache::set( $cache_key, $meta_box_template );
		}

		// prepare attributes
		{
			$attr_class = '';
			if ( isset( $other['attr']['class'] ) ) {
				$attr_class = ' ' . $other['attr']['class'];

				unset( $other['attr']['class'] );
			}

			unset( $other['attr']['id'] );
		}

		// replace placeholders with data/content
		return str_replace(
			array(
				$placeholders['id'],
				$placeholders['title'],
				$placeholders['content'],
				$placeholders['html_before_title'],
				$placeholders['html_after_title'],
				$placeholders['attr'],
				$placeholders['attr_class'],
			),
			array(
				esc_attr( $id ),
				$title,
				$content,
				$other['html_before_title'],
				$other['html_after_title'],
				fw_attr_to_html( $other['attr'] ),
				esc_attr( $attr_class )
			),
			$meta_box_template
		);
	}

	/**
	 * @param FW_Access_Key $access_key
	 * @param string|FW_Option_Type $option_type_class
	 *
	 * @internal
	 */
	public function _register_option_type( FW_Access_Key $access_key, $option_type_class, $type= null ) {
		if ( $access_key->get_key() !== 'fw_option_type' ) {
			trigger_error( 'Call denied', E_USER_ERROR );
		}

		$this->register_option_type( $option_type_class, $type );
	}

	/**
	 * @param FW_Access_Key $access_key
	 * @param string|FW_Container_Type $container_type_class
	 *
	 * @internal
	 */
	public function _register_container_type( FW_Access_Key $access_key, $container_type_class ) {
		if ( $access_key->get_key() !== 'fw_container_type' ) {
			trigger_error( 'Call denied', E_USER_ERROR );
		}

		$this->register_container_type( $container_type_class );
	}

	/**
	 * @param string $type
	 * @return FW_Option_Type
	 */
	public function option_type( $type ) {
		static $did_options_init = false;
		if ( ! $did_options_init ) {
			$did_options_init = true;
			do_action( 'fw_option_types_init' );
		}

		if ( isset( $this->option_types[ $type ] ) ) {
			if (is_string($this->option_types[$type])) {
				$this->option_types[$type] = $this->get_instance($this->option_types[$type]);
				$this->option_types[$type]->_call_init($this->get_access_key());
			}

			return $this->option_types[$type];
		} else {
			if ( is_admin() && apply_filters('fw_backend_undefined_option_type_warn_user', true, $type) ) {
				FW_Flash_Messages::add(
					'fw-get-option-type-undefined-' . $type,
					sprintf( __( 'Undefined option type: %s', 'fw' ), $type ),
					'warning'
				);
			}

			if ( ! $this->undefined_option_type ) {
				$this->undefined_option_type = new FW_Option_Type_Undefined();
			}

			return $this->undefined_option_type;
		}
	}

	/**
	 * Return an array with all option types names
	 *
	 * @return array
	 *
	 * @since 2.6.11
	 */
	public function get_option_types() {
		$this->option_type('text'); // trigger init
		return array_keys( $this->option_types );
	}

	/**
	 * Return an array with all container types names
	 *
	 * @return array
	 *
	 * @since 2.6.11
	 */
	public function get_container_types() {
		$this->container_type('box'); // trigger init
		return array_keys( $this->container_types );
	}

	/**
	 * @param string $type
	 * @return FW_Container_Type
	 */
	public function container_type( $type ) {
		static $did_containers_init = false;
		if ( ! $did_containers_init ) {
			$did_containers_init = true;
			do_action( 'fw_container_types_init' );
		}

		if ( isset( $this->container_types[ $type ] ) ) {
			if ( is_string( $this->container_types[ $type ] ) ) {
				$this->container_types[ $type ] = $this->get_instance( $this->container_types[$type] );
				$this->container_types[ $type ]->_call_init( $this->get_access_key() );
			}

			return $this->container_types[ $type ];
		} else {
			if ( is_admin() ) {
				FW_Flash_Messages::add(
					'fw-get-container-type-undefined-' . $type,
					sprintf( __( 'Undefined container type: %s', 'fw' ), $type ),
					'warning'
				);
			}

			if ( ! $this->undefined_container_type ) {
				$this->undefined_container_type = new FW_Container_Type_Undefined();
			}

			return $this->undefined_container_type;
		}
	}

	/**
	 * @param WP_Customize_Manager $wp_customize
	 * @internal
	 */
	public function _action_customize_register($wp_customize) {
		if (is_admin()) {
			add_action('admin_enqueue_scripts', array($this, '_action_enqueue_customizer_static'));
		}

		$this->customizer_register_options(
			$wp_customize,
			fw()->theme->get_customizer_options()
		);
	}

	/**
	 * @internal
	 */
	public function _action_enqueue_customizer_static()
	{
		{
			$options_for_enqueue = array();
			$customizer_options = fw()->theme->get_customizer_options();

			/**
			 * In customizer options is allowed to have container with unspecified (or not existing) 'type'
			 * fw()->backend->enqueue_options_static() tries to enqueue both options and container static
			 * not existing container types will throw notices.
			 * To prevent that, extract and send it only options (without containers)
			 */
			fw_collect_options($options_for_enqueue, $customizer_options, array(
				'callback' => array(__CLASS__, '_callback_fw_collect_options_enqueue_static'),
			));

			unset($options_for_enqueue, $customizer_options);
		}

		wp_enqueue_script(
			'fw-backend-customizer',
			fw_get_framework_directory_uri( '/static/js/backend-customizer.js' ),
			array( 'jquery', 'fw-events', 'backbone', 'fw-backend-options' ),
			fw()->manifest->get_version(),
			true
		);
		wp_localize_script(
			'fw-backend-customizer',
			'_fw_backend_customizer_localized',
			array(
				'change_timeout' => apply_filters('fw_customizer_option_change_timeout', 333),
			)
		);

		do_action('fw_admin_enqueue_scripts:customizer');
	}

	/**
	 * @param WP_Customize_Manager $wp_customize
	 * @param array $options
	 * @param array $parent_data {'type':'...','id':'...'}
	 */
	private function customizer_register_options($wp_customize, $options, $parent_data = array()) {
		$collected = array();

		fw_collect_options( $collected, $options, array(
			'limit_option_types' => false,
			'limit_container_types' => false,
			'limit_level' => 1,
			'info_wrapper' => true,
		) );

		if ( empty( $collected ) ) {
			return;
		}

		foreach ($collected as &$opt) {
			switch ($opt['group']) {
				case 'container':
					// Check if has container options
					{
						$_collected = array();

						fw_collect_options( $_collected, $opt['option']['options'], array(
							'limit_option_types' => array(),
							'limit_container_types' => false,
							'limit_level' => 1,
							'limit' => 1,
							'info_wrapper' => false,
						) );

						$has_containers = !empty($_collected);

						unset($_collected);
					}

					$children_data = array(
						'group' => 'container',
						'id' => $opt['id']
					);

					$args = array(
						'title' => empty($opt['option']['title'])
							? fw_id_to_title($opt['id'])
							: $opt['option']['title'],
						'description' => empty($opt['option']['desc'])
							? ''
							: $opt['option']['desc'],
					);

					if (isset($opt['option']['wp-customizer-args']) && is_array($opt['option']['wp-customizer-args'])) {
						$args = array_merge($opt['option']['wp-customizer-args'], $args);
					}

					if ($has_containers) {
						if ($parent_data) {
							trigger_error($opt['id'] .' panel can\'t have a parent ('. $parent_data['id'] .')', E_USER_WARNING);
							break;
						}

						$wp_customize->add_panel($opt['id'], $args);

						$children_data['customizer_type'] = 'panel';
					} else {
						if ($parent_data) {
							if ($parent_data['customizer_type'] === 'panel') {
								$args['panel'] = $parent_data['id'];
							} else {
								trigger_error($opt['id'] .' section can have only panel parent ('. $parent_data['id'] .')', E_USER_WARNING);
								break;
							}
						}

						$wp_customize->add_section($opt['id'], $args);

						$children_data['customizer_type'] = 'section';
					}

					$this->customizer_register_options(
						$wp_customize,
						$opt['option']['options'],
						$children_data
					);

					unset($children_data);
					break;
				case 'option':
					$setting_id = $this->get_options_name_attr_prefix() .'['. $opt['id'] .']';

					{
						$args_control = array(
							'label' => empty($opt['option']['label'])
								? fw_id_to_title($opt['id'])
								: $opt['option']['label'],
							'description' => empty($opt['option']['desc'])
								? ''
								: $opt['option']['desc'],
							'settings' => $setting_id,
						);

						if (isset($opt['option']['wp-customizer-args']) && is_array($opt['option']['wp-customizer-args'])) {
							$args_control = array_merge($opt['option']['wp-customizer-args'], $args_control);
						}

						if ($parent_data) {
							if ($parent_data['customizer_type'] === 'section') {
								$args_control['section'] = $parent_data['id'];
							} else {
								trigger_error('Invalid control parent: '. $parent_data['customizer_type'], E_USER_WARNING);
								break;
							}
						} else { // the option is not placed in a section, create a section automatically
							$args_control['section'] = 'fw_option_auto_section_'. $opt['id'];

							$wp_customize->add_section($args_control['section'], array(
								'title' => empty($opt['option']['label'])
									? fw_id_to_title($opt['id'])
									: $opt['option']['label'],
							));
						}
					}

					{
						$args_setting = array(
							'default' => fw()->backend->option_type($opt['option']['type'])->get_value_from_input($opt['option'], null),
							'fw_option' => $opt['option'],
							'fw_option_id' => $opt['id'],
						);

						if (isset($opt['option']['wp-customizer-setting-args']) && is_array($opt['option']['wp-customizer-setting-args'])) {
							$args_setting = array_merge($opt['option']['wp-customizer-setting-args'], $args_setting);
						}

						$wp_customize->add_setting(
							new _FW_Customizer_Setting_Option(
								$wp_customize,
								$setting_id,
								$args_setting
							)
						);

						unset($args_setting);
					}

					// control must be registered after setting
					$wp_customize->add_control(
						new _FW_Customizer_Control_Option_Wrapper(
							$wp_customize,
							$opt['id'],
							$args_control
						)
					);
					break;
				default:
					trigger_error('Unknown group: '. $opt['group'], E_USER_WARNING);
			}
		}
	}

	/**
	 * For e.g. an option-type was rendered using 'customizer' design,
	 * but inside it uses render_options() but it doesn't know the current render design
	 * and the options will be rendered with 'default' design.
	 * This method allows to specify the default design that will be used if not specified on render_options()
	 * @param null|string $design
	 * @internal
	 */
	public function _set_default_render_design($design = null)
	{
		if (empty($design) || !in_array($design, $this->available_render_designs)) {
			$this->default_render_design = 'default';
		} else {
			$this->default_render_design = $design;
		}
	}

	/**
	 * Get markdown parser with autoloading and caching
	 *
	 * Usage:
	 *   fw()->backend->get_markdown_parser()
	 *
	 * @param bool $fresh_instance Whether to force return a fresh instance of the class
	 *
	 * @return Parsedown
	 *
	 * @since 2.6.9
	 */
	public function get_markdown_parser($fresh_instance = false) {
		if (! $this->markdown_parser || $fresh_instance) {
			$this->markdown_parser = new Parsedown();
		}

		return $this->markdown_parser;
	}
}
