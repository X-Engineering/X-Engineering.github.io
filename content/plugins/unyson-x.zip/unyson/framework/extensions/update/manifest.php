<?php if (!defined('FW')) die('Forbidden');

$manifest = array();

$manifest['name'] = __('Update', 'fw');
$manifest['description'] = __('Keep you framework, extensions and theme up to date.', 'fw');
$manifest['standalone'] = true;

$manifest['version'] = '1.0.12';
$manifest['github_update'] = 'ThemeFuse/Unyson-Update-Extension';
